import { useState } from "react";
import { Button } from "../Component/Button"
import { Message } from "../Component/Message"

export const CounterPage = () => {
 const [count , setCount] =  useState (0);
  // let count = 0;

    const updateCount = (val)=>{
        if (val=== '+' ){
        setCount(count +1) ; console.log(count); } else { setCount(count-1) ;  }
        console.log('count is ',count);
    } 
    return ( <div className='container'>
<Message classname = 'alert alert-danger' msg = "Counter App  "/>
<Message  classname  ='alert alert-success' msg = "Counter Value is   " value ={count}  />
   <Button fn = {updateCount}  val = "+" classname = "btn btn-success me-2"/>
   <Button fn = {updateCount}  val = "-" classname = "btn btn-danger"/>  
    </div>)
} 