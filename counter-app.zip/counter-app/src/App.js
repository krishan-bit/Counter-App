import logo from './logo.svg';
import './App.css';
import { CounterPage } from './Pages/CounterPage';

function App() {
  return (<>
 <h1></h1> 
     <CounterPage/>

      
       </>
  );
}

export default App;
